#ifndef W5N_MESSAGE_H
#define W5N_MESSAGE_H

#include "Date.h"
#include "Time.h"

#include <string>
#include <iostream>

struct Message
{
    std::string content;
    Date date;
    Time time;
};
#endif
